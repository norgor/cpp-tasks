# 1b
Det blir tolket fra venstre til høyre. 
E.g. `((((5 - 3) - Fraction(2, 1)) - 2) - Fraction(1, 1))`
Alle 3 blir operatorene blir brukt.
